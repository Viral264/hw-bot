// Author: Inokentiy
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { text, secret } = req.body || {};

  if (!process.env.SEND_SECRET || secret !== process.env.SEND_SECRET) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  if (!process.env.BOT_TOKEN) {
    return res.status(500).json({ error: 'BOT_TOKEN is not set' });
  }

  if (typeof text !== 'string' || text.trim() === '' || text.length > 4000) {
    return res.status(400).json({ error: 'Text must be 1 to 4000 characters' });
  }

  const chatId = process.env.CHAT_ID || '-1003838440620';

  const tgResponse = await fetch(
    `https://api.telegram.org/bot${process.env.BOT_TOKEN}/sendMessage`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text }),
    }
  );

  const data = await tgResponse.json();

  if (!data.ok) {
    return res.status(502).json({ error: data.description || 'Telegram error' });
  }

  return res.status(200).json({ ok: true });
}
